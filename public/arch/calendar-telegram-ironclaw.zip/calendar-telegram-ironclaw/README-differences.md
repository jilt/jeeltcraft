# Choosing between the packages

| Dimension | `calendar-telegram-subagents.zip` | `calendar-telegram-ironclaw.zip` |
|---|---|---|
| Runtime | Framework-neutral multi-subagent design | IronClaw-oriented capability-bound design |
| Agent boundary | Separate subagent prompts/tool lists | Orchestrator plus explicit runtime tools/capabilities |
| Credential isolation | Implement it in your runner/secret manager | Bind credentials to individual IronClaw tools; do not expose them to the orchestrator |
| Network control | Implement egress controls in app/container | Tool-specific egress allowlists recommended |
| Best use | You already have a Claude/Codex/custom agent runner | You want self-hosted, security-first agent runtime boundaries |
| Code required | Calendar, Telegram, ledger adapters | Same adapters, packaged as IronClaw tools/plugins |
| Portability | Higher | Tied to IronClaw tool/plugin APIs |

Both designs preserve the same safety properties: read-only Calendar access, event opt-in, privacy filtering, fixed Telegram destination, idempotency, auditable receipts, and dry-run-first deployment.
