# Deployment

1. Create two credential objects: Google read-only OAuth and Telegram publisher token.
2. Bind Google credentials only to `calendar-read`; bind Telegram credentials only to `telegram-send`.
3. Configure egress allowlists and a fixed Telegram group ID in the runtime.
4. Mount a persistent ledger volume/database.
5. Start in `DRY_RUN`; test event creation, updates, recurrence, cancellation, and duplicate delivery.
6. Configure a schedule first. Add a validated Google webhook receiver only after polling works.
