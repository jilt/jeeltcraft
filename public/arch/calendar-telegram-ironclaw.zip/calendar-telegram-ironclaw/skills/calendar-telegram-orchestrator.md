# calendar-telegram-orchestrator

Goal: announce opted-in Calendar events safely.

1. Invoke `calendar-read`.
2. Pass normalized event JSON to `event-format`.
3. Invoke `delivery-ledger.check` with a deterministic idempotency key.
4. Apply `policies/notification-policy.yaml`.
5. In DRY_RUN, write the artifact and stop.
6. In SEND mode, invoke `telegram-send` using the exact approved text.
7. Store the Telegram receipt with `delivery-ledger.record`.

Never ask for, output, or forward credentials. Never send raw event descriptions, attendees, or conferencing URLs by default.
