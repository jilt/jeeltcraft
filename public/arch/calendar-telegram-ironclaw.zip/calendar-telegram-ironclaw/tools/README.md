# Capability-scoped tool contracts

## calendar-read
Input: calendar ID, event ID or sync/time window. Output: normalized event JSON. Credential: Google OAuth with `calendar.events.readonly`. Network allowlist: Google Calendar and OAuth endpoints only.

## event-format
Input: approved display fields. Output: escaped Telegram MarkdownV2 text. Credential/network: none.

## delivery-ledger
Input: idempotency key and receipt. Output: prior delivery status or stored receipt. Credential: database only. Network: none.

## telegram-send
Input: approved text and idempotency key. Output: Telegram `message_id`. Credential: bot token injected by runtime. Network allowlist: `api.telegram.org` only. Destination: fixed runtime configuration, never caller-selected.
