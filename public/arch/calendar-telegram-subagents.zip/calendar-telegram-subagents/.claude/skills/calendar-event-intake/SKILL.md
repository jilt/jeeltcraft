---
name: calendar-event-intake
description: Retrieve and normalize Google Calendar events.
disable-model-invocation: true
---
Fetch by event ID for webhooks, or list using `singleEvents=true`, a time window, and a stored sync token for scheduled runs. Persist `nextSyncToken` after a complete sync. A 410 response requires full resync. Emit normalized JSON only.
