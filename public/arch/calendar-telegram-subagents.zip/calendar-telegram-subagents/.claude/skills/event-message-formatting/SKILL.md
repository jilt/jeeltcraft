---
name: event-message-formatting
description: Render concise privacy-safe Telegram event messages.
---
Include title, local start/end, timezone, and location only when present. Escape MarkdownV2. Keep below 1000 characters. Never render attendees, raw descriptions, attachments, organizer, or conference URLs unless policy permits.
