---
name: telegram-delivery
description: Deliver pre-approved message via a fixed Telegram destination.
disable-model-invocation: true
---
Require APPROVED status and an undelivered idempotency key. Call only the configured adapter. Record returned Telegram message ID. Retry transient failures at most three times.
