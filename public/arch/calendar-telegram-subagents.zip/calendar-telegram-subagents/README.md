# Calendar to Telegram — Subagent Workflow

## Purpose
Read eligible Google Calendar events and send concise, privacy-safe event details to **one configured Telegram group**. This package deliberately separates event retrieval, policy/formatting, and external delivery.

## What it does
1. A schedule or Google Calendar webhook creates a run.
2. The event fetcher retrieves new/changed/upcoming events using a read-only Google Calendar adapter.
3. The formatter selects only policy-approved fields and renders a Telegram-safe message.
4. The validator applies opt-in, privacy, freshness, and deduplication rules.
5. The publisher sends only an already-approved message to one allowlisted Telegram chat.
6. A ledger records delivery state and the Telegram message ID.

## Security invariants
- Use Google OAuth scope `https://www.googleapis.com/auth/calendar.events.readonly`.
- Never store Google OAuth tokens or Telegram tokens in Markdown, Git, logs, or LLM context.
- Use a dedicated **Announcements** calendar or `extendedProperties.private.telegram_notify=true`.
- Do not publish attendee lists, raw descriptions, attachments, or meeting links unless explicitly enabled.
- Deduplicate using `sha256(calendar_id + event_id + updated + notification_type)`.
- Begin with `DRY_RUN`; require an explicit environment flag before live delivery.

## Message example
```text
📅 Protocol Partners Call
🕒 Tue 18 Aug, 14:00–14:45 (Europe/Rome)
📍 Google Meet
```

## Environment
Copy `.env.example` to `.env`; use your secret manager in production.

## Test plan
- New eligible event
- Modified event: one update only per changed `updated` version
- Recurring event instance
- All-day event and timezone conversion
- Cancelled event
- Missing location / missing summary
- Private event and event without opt-in property
- Telegram network error and retry
- Duplicate invocation / replayed webhook

## Sources
- Google Calendar Events API: https://developers.google.com/workspace/calendar/api/v3/reference/events
- Google Calendar push notifications: https://developers.google.com/workspace/calendar/api/guides/push
- Telegram Bot API: https://core.telegram.org/bots/api

## Runtime model
This is framework-neutral. An orchestrator invokes five purpose-built subagents, each with a minimal tool set. Deploy the adapters and scheduler in Python, TypeScript, or your own agent runner.

See [WORKFLOW.md](WORKFLOW.md), `.claude/agents/`, and `.claude/skills/`.
