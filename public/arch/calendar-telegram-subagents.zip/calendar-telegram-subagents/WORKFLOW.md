# Workflow

```text
Trigger (cron or Google webhook)
  -> calendar-orchestrator
     -> event-fetcher (Google Calendar read-only)
     -> event-enricher (no network/secrets)
     -> event-validator (policy + ledger check)
     -> telegram-publisher (Telegram send-only)
     -> delivery-ledger
```

## Contracts

### `calendar-event.json`
```json
{
  "calendar_id": "announcements@example.com",
  "event_id": "abc123",
  "updated": "2026-08-14T17:00:00Z",
  "status": "confirmed",
  "summary": "Protocol Partners Call",
  "start": {"dateTime": "2026-08-18T14:00:00+02:00", "timeZone": "Europe/Rome"},
  "end": {"dateTime": "2026-08-18T14:45:00+02:00", "timeZone": "Europe/Rome"},
  "location": "Google Meet",
  "extendedProperties": {"private": {"telegram_notify": "true"}}
}
```

### `approved-message.json`
```json
{
  "status": "APPROVED",
  "idempotency_key": "sha256...",
  "notification_type": "CREATED",
  "text": "📅 *Protocol Partners Call*\n🕒 Tue 18 Aug, 14:00–14:45 \(Europe/Rome\)\n📍 Google Meet"
}
```
