# Adapters
Implement `calendar-read`, `delivery-ledger`, and `telegram-send` as deterministic code. Keep OAuth refresh, webhook validation, retries, and storage outside the LLM.
