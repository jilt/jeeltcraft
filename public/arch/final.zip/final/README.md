# Final — IronClaw Calendar to Telegram

A minimal, deterministic Google Calendar-to-Telegram workflow designed to run as one IronClaw scheduled job or sandboxed tool. It uses a JSON file for incremental-sync state and Telegram delivery deduplication; it does **not** require LLM subagents, a validator, or a database.

## Flow

```text
IronClaw scheduled job
  -> Python workflow
     -> Google Calendar incremental sync (read-only)
     -> deterministic opt-in filter + formatter
     -> Telegram sendMessage to fixed group
     -> atomic JSON state update
```

## Why this design

- **Simple:** one Python process, one JSON state file.
- **Safe:** read-only Google scope, opt-in event property, fixed Telegram recipient.
- **Reliable enough for one local worker:** sync token plus delivered-event versions prevents routine duplicate sends.
- **IronClaw-ready:** bind credentials to this single capability-scoped tool/job; do not provide them to an LLM prompt.

## Setup

1. Create a Google Cloud OAuth client, enable Calendar API, and obtain a refresh token with only `https://www.googleapis.com/auth/calendar.events.readonly`.
2. Create a Telegram bot, add it to the target group, and obtain its numeric `chat_id`.
3. Copy `.env.example` to `.env` and fill it using IronClaw secrets or your local secret manager.
4. Install dependencies: `python -m pip install -r requirements.txt`.
5. Run the first baseline sync: `python -m app.main`. It stores the Google sync token and sends **nothing**.
6. Add `telegram_notify=true` under the event’s private extended properties. Create/update an opted-in event, then run the command again.
7. Schedule the same command in IronClaw or cron every 5–10 minutes.

## IronClaw binding

Use one tool/job called `calendar-telegram-sync`:

- Inject `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, and `GOOGLE_REFRESH_TOKEN` only into this tool.
- Inject `TELEGRAM_BOT_TOKEN` and fixed `TELEGRAM_TARGET_CHAT_ID` only into this tool.
- Permit egress only to `oauth2.googleapis.com`, `www.googleapis.com`, and `api.telegram.org`.
- Mount `data/` as persistent writable storage.
- Start with `DELIVERY_MODE=DRY_RUN`, then set `SEND` only after testing.

See `ironclaw/TOOL-CONTRACT.md` for the exact capability intent.

## Event opt-in

The workflow announces only confirmed events containing:

```json
{
  "extendedProperties": {
    "private": { "telegram_notify": "true" }
  }
}
```

Use a dedicated announcement calendar if you do not want to add this property manually.

## Behavior

- First run: establishes a baseline and saves Google’s `nextSyncToken`; sends no old events.
- Later runs: uses the stored `sync_token` to retrieve changed events only.
- A delivery key combines event ID, Google `updated` timestamp, and notification type.
- A changed event version sends one new notification; unchanged replays are skipped.
- If Google invalidates the sync token with HTTP 410, the workflow clears it and re-baselines without deleting prior delivery records.
- Cancelled events are skipped.

## Limits

This is deliberately single-process. Do not run two copies concurrently against the same JSON file. If you later need concurrent workers, replace JSON persistence with SQLite or Postgres.

## Sources

- Google sync: https://developers.google.com/workspace/calendar/api/guides/sync
- Google events list: https://developers.google.com/workspace/calendar/api/v3/reference/events/list
- Telegram Bot API: https://core.telegram.org/bots/api
