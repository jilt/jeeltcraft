import os
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

SCOPE = "https://www.googleapis.com/auth/calendar.events.readonly"


def service():
    creds = Credentials(
        token=None,
        refresh_token=os.environ["GOOGLE_REFRESH_TOKEN"],
        token_uri="https://oauth2.googleapis.com/token",
        client_id=os.environ["GOOGLE_CLIENT_ID"],
        client_secret=os.environ["GOOGLE_CLIENT_SECRET"],
        scopes=[SCOPE],
    )
    creds.refresh(Request())
    return build("calendar", "v3", credentials=creds, cache_discovery=False)


def sync(calendar_id: str, sync_token: str | None):
    api = service().events()
    args = {"calendarId": calendar_id, "singleEvents": True, "showDeleted": True, "maxResults": 2500}
    if sync_token:
        args["syncToken"] = sync_token
    events, next_token, page = [], None, None
    while True:
        response = api.list(pageToken=page, **args).execute()
        events.extend(response.get("items", []))
        page = response.get("nextPageToken")
        if not page:
            next_token = response.get("nextSyncToken")
            break
    return events, next_token


def is_sync_token_invalid(error: HttpError) -> bool:
    return error.resp.status == 410
