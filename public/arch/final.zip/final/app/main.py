import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo
from googleapiclient.errors import HttpError
from .calendar_client import is_sync_token_invalid, sync
from .state import load_state, save_state
from .telegram_client import send


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def opted_in(event: dict) -> bool:
    value = event.get("extendedProperties", {}).get("private", {}).get("telegram_notify")
    return value == "true"


def local_time(value: dict, zone: ZoneInfo) -> str:
    if "date" in value:
        return value["date"]
    dt = datetime.fromisoformat(value["dateTime"].replace("Z", "+00:00"))
    return dt.astimezone(zone).strftime("%a %d %b, %H:%M")


def format_event(event: dict, zone: ZoneInfo) -> str:
    title = event.get("summary") or "Untitled event"
    start, end = local_time(event["start"], zone), local_time(event["end"], zone)
    lines = [f"📅 {title}", f"🕒 {start}–{end} ({zone.key})"]
    if event.get("location"):
        lines.append(f"📍 {event['location']}")
    return "\n".join(lines)[:1000]


def key(event: dict) -> str:
    raw = f"{event['id']}|{event.get('updated', '')}|CREATED"
    return hashlib.sha256(raw.encode()).hexdigest()


def baseline(state: dict, events: list, next_token: str | None) -> None:
    state["sync_token"] = next_token
    state["updated_at"] = now()
    save_state(os.environ["STATE_PATH"], state)
    print(f"Baseline complete: {len(events)} events observed; no messages sent.")


def main() -> None:
    state_path = os.environ.get("STATE_PATH", "data/calendar_telegram_state.json")
    os.environ["STATE_PATH"] = state_path
    calendar_id = os.environ["GOOGLE_CALENDAR_ID"]
    zone = ZoneInfo(os.environ.get("TIMEZONE", "Europe/Rome"))
    state = load_state(state_path)
    state["calendar_id"] = calendar_id
    try:
        events, next_token = sync(calendar_id, state.get("sync_token"))
    except HttpError as error:
        if not is_sync_token_invalid(error):
            raise
        state["sync_token"] = None
        save_state(state_path, state)
        events, next_token = sync(calendar_id, None)
        baseline(state, events, next_token)
        return
    if state.get("sync_token") is None:
        baseline(state, events, next_token)
        return
    for event in events:
        if event.get("status") == "cancelled" or not opted_in(event):
            continue
        delivery_key = key(event)
        if delivery_key in state["delivered"]:
            continue
        receipt = send(format_event(event, zone))
        state["delivered"][delivery_key] = {
            "event_id": event["id"],
            "event_updated": event.get("updated"),
            "telegram_message_id": receipt["result"]["message_id"],
            "sent_at": now(),
        }
        save_state(state_path, state)
    state["sync_token"] = next_token
    state["updated_at"] = now()
    save_state(state_path, state)


if __name__ == "__main__":
    main()
