import json
import os
from pathlib import Path
from tempfile import NamedTemporaryFile


def load_state(path: str) -> dict:
    file = Path(path)
    if not file.exists():
        return {"version": 1, "calendar_id": None, "sync_token": None, "delivered": {}, "updated_at": None}
    return json.loads(file.read_text())


def save_state(path: str, state: dict) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with NamedTemporaryFile("w", encoding="utf-8", dir=target.parent, delete=False) as tmp:
        json.dump(state, tmp, indent=2, sort_keys=True)
        tmp.write("\n")
        temp_name = tmp.name
    os.replace(temp_name, target)
