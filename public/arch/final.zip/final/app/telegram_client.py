import os
import requests


def send(text: str) -> dict:
    if os.environ.get("DELIVERY_MODE", "DRY_RUN").upper() != "SEND":
        return {"ok": True, "result": {"message_id": "dry-run"}}
    token = os.environ["TELEGRAM_BOT_TOKEN"]
    chat_id = os.environ["TELEGRAM_TARGET_CHAT_ID"]
    response = requests.post(
        f"https://api.telegram.org/bot{token}/sendMessage",
        json={"chat_id": chat_id, "text": text, "disable_web_page_preview": True, "protect_content": True},
        timeout=20,
    )
    response.raise_for_status()
    payload = response.json()
    if not payload.get("ok"):
        raise RuntimeError(str(payload))
    return payload
