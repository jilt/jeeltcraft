# `calendar-telegram-sync` tool contract

## Inputs
No model-provided inputs. Runtime configuration comes from injected environment secrets and persistent `data/` storage.

## Capabilities

| Capability | Restriction |
|---|---|
| Google OAuth | Read-only Calendar scope only |
| Calendar API | Read/list event resources only |
| Telegram | Only `sendMessage` to `TELEGRAM_TARGET_CHAT_ID` |
| Network | `oauth2.googleapis.com`, `www.googleapis.com`, `api.telegram.org` only |
| Filesystem | Read code/policy; write only persistent `data/calendar_telegram_state.json` |
| LLM | Not required |

## Invocation

```text
python -m app.main
```

Run it on a schedule. Do not permit arbitrary chat input to select a calendar, chat ID, event field set, or delivery mode.
