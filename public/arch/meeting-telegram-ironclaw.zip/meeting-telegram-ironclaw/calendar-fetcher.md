# Calendar Fetcher - Google Calendar extension

OpenCode role `calendar-fetcher` -> IronClaw equivalent: **Google Calendar extension**.

- Installed via `Extensions -> Registry`.
- Credentials configured in `Admin -> Configuration` (Google OAuth client values).
- Permission in `Settings -> Tools`: read-only access.
- Capability used by the Automation: read/list.
- Never modifies Calendar data.
- Returns normalized events matching the shared contract (normalized-event).
- Tokens stay out of Skills, prompts, Markdown, logs, and model context.
