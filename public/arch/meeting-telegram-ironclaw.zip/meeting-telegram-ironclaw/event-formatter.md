# Event Formatter - deterministic formatter or constrained Skill

OpenCode role `event-formatter` -> IronClaw equivalent: **local deterministic transformation** (or a constrained Skill).

Include only:
- summary
- local start and end
- timezone
- location when present

Exclude descriptions, attendees, attachments, organizers, and conference URLs.
Never invent missing values. Return structured output.
