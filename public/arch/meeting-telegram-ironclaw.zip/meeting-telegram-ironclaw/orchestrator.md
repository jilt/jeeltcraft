# Orchestrator - IronClaw Automation

OpenCode role `meeting-orchestrator` -> IronClaw equivalent: **IronClaw Automation**.

## Setup

1. Install extensions in `Extensions -> Registry`: Calendar extension and Telegram extension.
2. Configure credentials in `Admin -> Configuration`: the Google OAuth client values through the Google Calendar configuration, and the Telegram bot deployment through the Telegram configuration fields. Keep tokens out of Skills, prompts, Markdown, logs, and model context.
3. Configure permissions in `Settings -> Tools`: conservative global and per-tool settings. Give Calendar read-only access and Telegram send access only to the configured channel/destination. Do not grant the orchestrator arbitrary network access or arbitrary recipient selection.
4. Create the Automation in `Automations -> New Automation`.

## Configuration

```
Name: Prepare opted-in Calendar meeting for Telegram
Trigger: every 5-10 minutes
Mode: DRY_RUN initially
Calendar: allowlisted announcement calendar
Telegram destination: fixed configured destination
```

## Steps

1. Call Google Calendar read/list capability.
2. Normalize changed or upcoming events.
3. Apply the opt-in and privacy policy.
4. Format the approved message locally.
5. Check persistent idempotency state.
6. In DRY_RUN, store/display the message and stop.
7. In SEND, call the native Telegram extension.
8. Record the Telegram receipt and state.

## Testing checklist (dry run, before enabling delivery)

- First baseline sync sends nothing.
- A confirmed opted-in event produces one message.
- An event without the opt-in property is rejected.
- A cancelled event is rejected.
- A changed event produces one new version.
- Replaying the same event does not duplicate delivery.
- An all-day event formats correctly.
- Timezone conversion is correct.
- Missing location does not create an empty location line.
- Descriptions and attendees are not included.
- Telegram failure is retried without losing idempotency state.
- An unknown destination cannot be selected by the model.

## Policy

The workflow must:

- Read Calendar data without modifying it.
- Require `extendedProperties.private.telegram_notify == "true"`.
- Skip cancelled events.
- Include title, local start/end, timezone, and optional location.
- Exclude attendees, descriptions, attachments, organizers, and conference URLs by default.
- Use a fixed Telegram destination.
- Avoid duplicate delivery.
- Begin in dry-run mode.

## Shared contract

### Normalized Event

```json
{
  "calendar_id": "announcements@example.com",
  "event_id": "abc123",
  "updated": "2026-08-18T09:00:00Z",
  "status": "confirmed",
  "summary": "Protocol Partners Call",
  "start": {
    "dateTime": "2026-08-18T14:00:00+02:00",
    "timeZone": "Europe/Rome"
  },
  "end": {
    "dateTime": "2026-08-18T14:45:00+02:00",
    "timeZone": "Europe/Rome"
  },
  "location": "Google Meet",
  "extendedProperties": {
    "private": {
      "telegram_notify": "true"
    }
  }
}
```

### Approved Message

```json
{
  "status": "APPROVED",
  "idempotency_key": "sha256(calendar_id|event_id|updated|CREATED)",
  "notification_type": "CREATED",
  "text": "\ud83d\udcc5 Protocol Partners Call\n\ud83d\udd52 Tue 18 Aug, 14:00\u201314:45 (Europe/Rome)\n\ud83d\udccd Google Meet"
}
```
