# Policy Validator - deterministic Automation policy step

OpenCode role `policy-validator` -> IronClaw equivalent: **deterministic Automation policy step** (optional model only for ambiguity).

Approve only when:
- status is confirmed;
- the calendar ID is allowlisted;
- private.telegram_notify equals "true";
- the event is not cancelled;
- the idempotency key is not already delivered (persistent IronClaw state or scoped state tool as delivery ledger);
- the destination is the configured fixed destination.

## Optional reasoning stage

If the workflow later needs an AI-generated summary, add a bounded reasoning stage between Calendar retrieval and deterministic validation:

```
Calendar extension
  -> summarizer subagent: draft summary only
  -> policy validator: approve fields and length
  -> formatter
  -> Telegram extension
```

The summarizer must not receive Telegram credentials or delivery authority. Its output must be treated as an untrusted proposal until deterministic validation approves it.
