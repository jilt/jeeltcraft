# Telegram Publisher - Telegram extension

OpenCode role `telegram-publisher` -> IronClaw equivalent: **Telegram extension**.

- Installed via `Extensions -> Registry`.
- Bot deployment configured in `Admin -> Configuration` (Telegram configuration fields).
- Permission in `Settings -> Tools`: send access only to the fixed configured destination.
- Sends only approved text; does not change the message text and does not select a chat ID.
- Records the Telegram receipt and terminal status in the delivery ledger (persistent IronClaw state or state tool).
- Never outputs credentials.
